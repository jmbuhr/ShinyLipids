#ifndef RSQLITE_UTILS_H
#define RSQLITE_UTILS_H

void warning_once(const std::string& msg);

#endif //RSQLITE_UTILS_H
