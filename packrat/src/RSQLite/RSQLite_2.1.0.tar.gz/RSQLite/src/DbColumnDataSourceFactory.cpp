#include "pch.h"
#include "DbColumnDataSourceFactory.h"

DbColumnDataSourceFactory::DbColumnDataSourceFactory() {
}

DbColumnDataSourceFactory::~DbColumnDataSourceFactory() {
}
